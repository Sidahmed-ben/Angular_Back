const Ticket = require('./ticket.model.js');
const Student = require('./student.model.js');

module.exports = {
  Ticket, Student,
};
